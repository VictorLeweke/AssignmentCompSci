Our project for computer science modelling course

-------
Description
This is the fourth part of the project; 
This part focuses on implementation of a "Detection of Signs" analysis.
This means that it will evaluate the possible sign of each variable at each node in a GCL program.
It also includes functionality for inputting multiple initial abstract memories.


----------
Instructions
download the .zip file from the assignment hand-in or MA_part4.zip from 
github-repository's main branch: (https://github.com/VictorLeweke/AssignmentCompSci)

Run the entire code of "ProjectPart4.fsx" in F#, and enter "alCompute 3" as a command to get three chances at inputting GCLs.
Then enter the desired GCL. 
Then, enter how many abstract memories you want initialized, and enter them afterwards, as done on formalmethods.dk.
Then, the GCL will be analysed!
The number of abstract memories to be input can be (from 1 to very high).
The GCL should not have any newlines, at least if the input is through visual code - it doesn't seem to appreciate it too much.

The FSLexYacc should be installed in the same directory as the files.


----------
Files important for this part is:
ProjectPart4.fsx (MAIN file)

ProjectTypesAST.fs

AbstractTypes.fs
AbstParser.fs
AbstLexer.fs

ProjectParser.fs
ProjectLexer.fs

InitTypesAST.fs
InitParser.fs
InitLexer.fs

SupportFunctions.fs

Most of these should be included so as to still have the functionality from part 3 (and below).