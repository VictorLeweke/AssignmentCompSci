module AbstractTypes


type Sign = 
  | Plus
  | Minus
  | Zero

type boolSign = 
  | TT
  | FF

type AbsVars = Map<string,Sign>
// x = -, y = +, z = 0
type AbsArrs = Map<string,Set<Sign>>
// A[] = {0}, B[] = {+,0}

type AbsMemory = Set<Map<string,Sign> * Map<string,Set<Sign>>>
// {x = -, y = +, z = 0, B[] = {+,0},
// x = +, y = +, z = -, B[] = {-,0}}


//Types for AbstractParser
type absvarsparse =
    | AbsComma of absvarsparse*absvarsparse
    | AbsArray of string*abslstparse
    | AbsAssign of string*abssignparse
and abslstparse =
    | AbsLstComma of abssignparse*abslstparse
    | AbsLstSign of abssignparse 
and abssignparse =
    | AbsPlus
    | AbsMinus
    | AbsZero

// x = -, y = -, z = +

// {-,+,0} -> {-,0} , {-,+} , {+,0}


// {x = -, y = +, z = 0
// x = +, y = +, z = +, }
// { A = {0,-}
//  A = {-} }



// {x = +
// x = -}
// x > 0
// x < 0