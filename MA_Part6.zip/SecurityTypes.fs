module SecurityTypes

type Flow = Set<(string * string)>;;


type Secure = Flow;;
type SecLevel = string;;
type SecLattice = (SecLevel * SecLevel) list;;
type SecClass = Map<SecLevel,string list>;; //(string * SecLevel) list;;


