module SecLatTypes

type privacycomp = 
    | SecLatLess of string*string
and complist =
    | SecLatList of privacycomp*complist
    | SecLatComma of privacycomp*privacycomp
    | SecLatEnd of privacycomp
