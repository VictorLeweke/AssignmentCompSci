module SecClassTypes

type SecClassList =
    | SecClassComma of SecClassList * SecClassList
    | SecClassAssign of string * string


// type initMain =
//   | Comma of initMain*initMain
//   | IAssign of string*initNums
//   | IArray of string*initNums*initNums
// and initLst =
//   | Lst of initNums*initLst
//   | LstNumba of initNums
// and initNums =
//   | UMinus of initNums
//   | Numba of float



// let rec sec (cmd : cmd ) (X : Set<string> ) : Flow =
//     match (cmd) with 
//     | Assignment(x,y) ->  (Set.union X (fva y)) |> makeFlow (Set.empty.Add(x))
//     | ArrayAs(x,y,z) -> (Set.union (Set.union X (fva y)) (fva z)) |> makeFlow (Set.empty.Add(x))
//     | Null -> (Set.empty) //instructions wanted this to be "true", but isnt applicable to F sharp.
//     | Then(x,y) -> Set.union (sec x X) (sec y X)
//     | If(x) -> tupleHead (secG x (False,X))
//     | Do(x) -> tupleHead (secG x (False,X))
// and secG (gc : gc) ((b,X) : boolean * Set<String>) : (Flow * boolean ) = 
//     match gc with
//     | Arrow(x,y) -> (sec y (Set.union (X) (Set.union (fvb x) (fvb b))),Ors(b,x))
//     | Ifelse(x,y) -> let (w1,d1) = secG x (b,X)
//                      let (w2,d2) = secG y (d1,X)
//                      (Set.union w1 w2),d2