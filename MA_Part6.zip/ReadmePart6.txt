Our project for computer science modelling course

-------
Description
This is the sixth part of the project; 
This part focuses on implementation of model checking.
This means that it will find all the reachable stuck states, given a GCL program and initial configuration.

----------
Instructions
download the .zip file from the assignment hand-in or MA_part6.zip from 
github-repository's main branch: (https://github.com/VictorLeweke/AssignmentCompSci)

Run the entire code of "ProjectPart6.fsx" in F#, and enter the desired GCL. 
Then, enter the GCL program, the initial values of variables and the initial node
Then the script will output the reachable stuck states from a set.
The GCL should not have any newlines, at least if the input is through visual code - it doesn't seem to appreciate it too much.

The FSLexYacc should be installed in the same directory as the files.


----------
Files important for this part is:
ProjectPart6.fsx (MAIN file)

ProjectTypesAST.fs


ProjectParser.fs
ProjectLexer.fs

InitTypesAST.fs
InitParser.fs
InitLexer.fs

SupportFunctions.fs

SecurityTypes.fs
SecLatTypes.fs
SecClassTypes.fs

SecLatParser.fs
SecLatLexer.fs
SecClassParser.fs
SecClassLexer.fs


Most of these should be included so as to still have the functionality from part 5 and part 3 (and below).